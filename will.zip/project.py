import os
import sys

import pygame
import time
import csv
import pyglet

if __name__ == '__main__':
    vilet = 0

    pygame.init()
    pygame.display.set_caption('Движущийся круг 2')
    size = width, height = 800, 400
    screen = pygame.display.set_mode(size)
    k = 0
    animka = ["idle.png", "photo_2021-12-17_21-34-03 (6).jpg", "box.png"]
    otskok = 0
    a4 = []
    right = 700
    sel = 0
    dog_surf = pygame.image.load('idle.png')

    pygame.display.update()

    running = True
    x_pos = 0
    v = 20  # пикселей в секунду
    clock = pygame.time.Clock()
    pers = [200, 200]
    button = [70, 340]
    green = (0, 255, 0)
    red = (255, 0, 0)
    zvet = red
    box1 = [500, 270]
    box2 = [583, 150]
    popal = 0
    level = 1
    lvl = 0
    # ffff
    box = [400, 160]
    vzyal = 0
    left = 80
    button3 = [80, 340]
    fir = 0
    nachalo_poletel = [0, 0]
    kak_letit = 0
    konez_surf = pygame.image.load(
        'depositphotos_32691869-stock-illustration-vector-pixel-message-game-over.jpg')
    a = [-100, 500]
    konez_rect = konez_surf.get_rect(
        bottomright=(a))


    def load_image(name, colorkey=None):
        fullname = os.path.join('data', name)
        # если файл не существует, то выходим
        if not os.path.isfile(fullname):
            print(f"Файл с изображением '{fullname}' не найден")
            sys.exit()
        image1 = pygame.image.load(fullname)
        if colorkey is not None:
            image1 = image1.convert()
            if colorkey == -1:
                colorkey = image1.get_at((0, 0))
            image1.set_colorkey(colorkey)
        else:
            image1 = image1.convert_alpha()
        return image1
        py_surf = pygame.image.load(image1)

        dog_rect = py_surf.get_rect(
            bottomright=(pers[0], pers[1]))
        screen.blit(py_surf, dog_rect)


    image1 = load_image(
        'png-transparent-ar-15-style-rifle-gun-barrel-colt-ar-15-receiver-upper-arm-angle-car-weapon.png')


    def playsound(lick):
        if lick == 1:
            pygame.mixer.music.load('Tomas Dvorak-By the Wall-kissvk.com.mp3')
            pygame.mixer.music.play()
            pygame.mixer.music.set_volume(0.05)
        if lick == 2:
            pygame.mixer.music.stop()
            pygame.mixer.music.load('WEEDMANE- Suicideyear-SUICIDE YEAR-kissvk.com.mp3')
            pygame.mixer.music.play()
            pygame.mixer.music.set_volume(0.05)


    def stopsound():
        pyglet.app.exit


    def rotate(img, pos, angle):
        w, h = img.get_size()
        img2 = pygame.Surface((w * 2, h * 2), pygame.SRCALPHA)
        img2.blit(img, (w - pos[0], h - pos[1]))
        return pygame.transform.rotate(img2, angle)


    playsound(1)
    imagec = pygame.image.load("rectangle.png").convert_alpha()
    pivot = (190, 320)  # положение центра вращения на экране
    angle = 100
    center_image = (50, 22.5)  # положение центра вращения на изображении

    while running:
        import csv

        with open('level.csv') as File:
            reader = csv.reader(File, delimiter=',', quotechar=',',
                                quoting=csv.QUOTE_MINIMAL)
            for row in reader:
                for i in row:
                    lvl = i
        screen.fill((0, 0, 0))
        if lvl == "1":
            pygame.draw.rect(screen, (255, 250, 255),
                             (0, 15, 120, 30))
            f1 = pygame.font.Font(None, 36)
            text1 = f1.render('level 1', True,
                              (125, 125, 125))
            screen.blit(text1, (5, 15))
        if lvl == "2":
            pygame.draw.rect(screen, (255, 250, 255),
                             (0, 15, 120, 30))
            f1 = pygame.font.Font(None, 36)
            text1 = f1.render('level 2', True,
                              (125, 125, 125))
            screen.blit(text1, (5, 15))
        if lvl == "3":
            pygame.draw.rect(screen, (255, 250, 255),
                             (0, 15, 120, 30))
            f1 = pygame.font.Font(None, 36)
            text1 = f1.render('level 3', True,
                              (125, 125, 125))
            screen.blit(text1, (5, 15))

        if vzyal == 1:
            box1[1] = (pers[1] - 50)
        if pers[0] <= 75:
            level = 3
            lvl = "3"
            with open('level.csv', 'w', newline='') as csvfile:
                spamwriter = csv.writer(csvfile, delimiter=' ',
                                        quotechar='|', quoting=csv.QUOTE_MINIMAL)
                spamwriter.writerow(lvl)
        if level == 3:
            if pers[1] <= 340:
                pers[1] += 10
            zvet = red
            dog_surf = pygame.image.load('idle.png')

            left = 80

            if box2[0] >= (button3[0] - 30) and box2[0] <= (button3[0] + 90) and vzyal == 0:
                zvet = green
                button3[1] = 345
            elif vzyal == 0 and popal == 1 and box2[1] <= 300:
                box2[1] += 10
            elif (pers[0] >= (button3[0]) and pers[0] <= (button3[0] + 90)) and pers[1] >= 340:
                zvet = green
                button3[1] = 345
            else:
                zvet = red
                button3[1] = 340
            if box2[0] <= 30:
                box2[0] += 20
            if box2[0] >= 700:
                box2[0] -= 20

            if vilet == 1:
                pygame.draw.circle(screen, (125, 125, 125),
                                   (nachalo_poletel[0], nachalo_poletel[1]), 20)

                if nachalo_poletel[0] >= 570 and nachalo_poletel[1] <= 150:
                    otskok = 0
                    vilet = 0
                    popal = 1

                if nachalo_poletel[1] >= 110 and otskok == 0:
                    nachalo_poletel[0] += kak_letit
                    nachalo_poletel[1] -= 3
                elif nachalo_poletel[1] <= 330:
                    otskok = 1
                    nachalo_poletel[0] += kak_letit
                    nachalo_poletel[1] += 3
                else:
                    otskok = 0
                    vilet = 0

            # положение центра вращения на изображении

            image = rotate(imagec, center_image, angle)
            rect = image.get_rect()
            rect.center = pivot
            screen.blit(image, rect)

            if pers[0] <= 80:
                pers[0] += 10
            if zvet == green:
                right = 1000
            elif zvet == red:
                right = 700
            if popal == 0:
                pygame.draw.rect(screen, (125, 125, 125),
                                 (600, 70, 5, 100))
            pygame.draw.rect(screen, (255, 125, 125),
                             (button3[0], button3[1], 70, 20))

            pygame.draw.rect(screen, (150, 75, 0),
                             (190, 340, 50, 15))

            pygame.draw.rect(screen, (255, 255, 255),
                             (0, 350, 1000, 500))

            pygame.draw.rect(screen, (255, 255, 255),
                             (0, 70, 30, 340))
            pygame.draw.rect(screen, (zvet),
                             (700, 90, 20, 350))
            pygame.draw.rect(screen, (255, 255, 255),
                             (0, 70, 1400, 20))
            pygame.draw.rect(screen, (150, 75, 0),
                             (box2[0], box2[1], 40, 40))
            if pers[0] >= 770:
                level = 4

        dog_rect = dog_surf.get_rect(
            bottomright=(pers[0], pers[1]))
        screen.blit(dog_surf, dog_rect)
        if level == 4:
            right = 190
            if a[0] != 800:
                if k == 0:
                    screen.fill((0, 0, 0))
                    a[0] += 10
                    konez_rect = konez_surf.get_rect(
                        bottomright=(a))
                    screen.blit(konez_surf, konez_rect)
            else:
                konez_rect = konez_surf.get_rect(
                    bottomright=(a))
                screen.blit(konez_surf, konez_rect)

        if level == 2:
            if box2[0] <= 30:
                box2[0] += 20
            if box2[0] >= 700:
                box2[0] -= 20
            zvet = red
            button = [460, 200]
            if pers[1] == 150 and (pers[0] >= 370 and pers[0] <= 480):
                pass
            elif pers[1] <= 340 and (pers[0] <= 340 or pers[0] >= 380):
                pers[1] += 10

            if pers[1] == 150:
                right = 460
            elif pers[1] == 350:
                right = 770

            if box1[0] >= (button[0]) and box1[0] <= (button[0] + 90) and box1[1] == 170:
                zvet = green
                button[1] = 205
            elif (vzyal == 0 and (box1[0] <= 370 or box1[0] >= 470) and box1[1] != 310):
                box1[1] += 10
            elif (pers[0] >= (button[0]) and pers[0] <= (button[0] + 90)) and pers[1] == 200:
                zvet = green
                button[1] = 205
            if zvet == green:
                left = 0
            elif zvet == red:
                left = 80


            else:
                zvet = red
                button[1] = 200
            box = [0, 0]
            whi = 160
            pygame.draw.rect(screen, (255, 255, 255),
                             (450, 70, 15, 35))
            pygame.draw.rect(screen, (255, 125, 125),
                             (button[0], button[1], 70, 20))
            pygame.draw.rect(screen, (255, 255, 255),
                             (450, 210, 90, 15))
            pygame.draw.rect(screen, (255, 255, 255),
                             (0, 350, 1000, 500))
            pygame.draw.rect(screen, (255, 255, 255),
                             (770, 70, 30, 340))
            pygame.draw.rect(screen, (zvet),
                             (30, 60, 20, 350))
            pygame.draw.rect(screen, (255, 255, 255),
                             (0, 60, 1400, 20))
            pygame.draw.rect(screen, (120, 120, 120),
                             (300, 150, 10, 200))
            pygame.draw.rect(screen, (120, 120, 120),
                             (340, 150, 10, 200))
            pygame.draw.rect(screen, (120, 120, 120),
                             (300, 170, 40, 10))
            pygame.draw.rect(screen, (120, 120, 120),
                             (300, 190, 40, 10))
            pygame.draw.rect(screen, (255, 255, 255),
                             (350, 150, 100, 30))
            pygame.draw.rect(screen, (120, 120, 120),
                             (300, 210, 40, 10))
            pygame.draw.rect(screen, (120, 120, 120),
                             (300, 230, 40, 10))
            pygame.draw.rect(screen, (120, 120, 120),
                             (300, 250, 40, 10))
            pygame.draw.rect(screen, (120, 120, 120),
                             (300, 270, 40, 10))
            pygame.draw.rect(screen, (120, 120, 120),
                             (300, 290, 40, 10))
            pygame.draw.rect(screen, (120, 120, 120),
                             (300, 310, 40, 10))
            pygame.draw.rect(screen, (120, 120, 120),
                             (300, 330, 40, 10))

            pygame.draw.rect(screen, (120, 120, 120),
                             (300, 330, 40, 10))
            pygame.draw.rect(screen, (150, 75, 0),
                             (box1[0], box1[1], 40, 40))
            dog_rect = dog_surf.get_rect(
                bottomright=(pers[0], pers[1]))
            screen.blit(dog_surf, dog_rect)
        if vzyal == 1:
            box[1] = (pers[1] - 50)

        if level == 1:
            if box2[0] <= 30:
                box2[0] += 20
            if box2[0] >= 700:
                box2[0] -= 20

            right = 700
            whi = 210
            if pers[1] == 200 and (pers[0] >= 370 and pers[0] <= 480):
                pass
            elif pers[1] <= 340 and (pers[0] <= 340 or pers[0] >= 380):
                pers[1] += 10
            if pers[0] == 740:
                level = 2
                lvl = "2"
                with open('level.csv', 'w', newline='') as csvfile:
                    spamwriter = csv.writer(csvfile, delimiter=' ',
                                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
                    spamwriter.writerow(lvl)
            if box[0] >= 700:
                box[0] -= 70

            if vzyal == 0 and (box[0] <= 370 or box[0] >= 470) and box[1] != 310:
                box[1] += 10
            if box[0] >= (button[0]) and box[0] <= (button[0] + 90):
                zvet = green
                button[1] = 345
            elif (pers[0] >= (button[0]) and pers[0] <= (button[0] + 90)) and pers[1] >= 340:
                zvet = green
                button[1] = 345
            else:
                zvet = red
                button[1] = 340
            pygame.draw.rect(screen, (255, 125, 125),
                             (button[0], button[1], 70, 20))
            pygame.draw.rect(screen, (255, 255, 255),
                             (0, 350, 1000, 500))

            pygame.draw.rect(screen, (255, 255, 255),
                             (0, 70, 30, 340))
            pygame.draw.rect(screen, (zvet),
                             (700, 90, 20, 350))
            pygame.draw.rect(screen, (255, 255, 255),
                             (0, 70, 1400, 20))
            pygame.draw.rect(screen, (120, 120, 120),
                             (300, 200, 10, 150))
            pygame.draw.rect(screen, (120, 120, 120),
                             (340, 200, 10, 150))
            pygame.draw.rect(screen, (255, 255, 255),
                             (350, 200, 100, 30))
            pygame.draw.rect(screen, (120, 120, 120),
                             (300, 210, 40, 10))
            pygame.draw.rect(screen, (120, 120, 120),
                             (300, 230, 40, 10))
            pygame.draw.rect(screen, (120, 120, 120),
                             (300, 250, 40, 10))
            pygame.draw.rect(screen, (120, 120, 120),
                             (300, 270, 40, 10))
            pygame.draw.rect(screen, (120, 120, 120),
                             (300, 290, 40, 10))
            pygame.draw.rect(screen, (120, 120, 120),
                             (300, 310, 40, 10))
            pygame.draw.rect(screen, (120, 120, 120),
                             (300, 330, 40, 10))
            pygame.draw.rect(screen, (150, 75, 0),
                             (box[0], box[1], 40, 40))

            dog_rect = dog_surf.get_rect(
                bottomright=(pers[0], pers[1]))
            screen.blit(dog_surf, dog_rect)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        keys = pygame.key.get_pressed()
        if keys[pygame.K_f]:

            if level == 3:
                if sel == 0:
                    if pers[0] >= 190 and pers[0] <= 250:
                        sel = 1
                else:
                    sel = 0
            if level == 1:
                if pers[1] == (box[1] + 40) and pers[0] >= (box[0] - 40) and pers[0] <= (box[0] + 40):
                    box[1] -= 10
                    vzyal = 1
                elif vzyal == 1:
                    vzyal = 0
                    box[1] += 10
                    box[0] += 5
            elif level == 2:
                if pers[1] == (box1[1] + 40) and pers[0] >= (box1[0] - 40) and pers[0] <= (box1[0] + 40):
                    box1[1] -= 10
                    vzyal = 1
                elif vzyal == 1:
                    vzyal = 0
                    box1[1] += 10
                    box1[0] += 5
            elif level == 3:
                if pers[1] == (box2[1] + 40) and pers[0] >= (box2[0] - 40) and pers[0] <= (box2[0] + 40):
                    box2[1] -= 10
                    vzyal = 1
                elif vzyal == 1:
                    vzyal = 0
                    box2[1] += 10
                    box2[0] += 5
        if keys[pygame.K_SPACE]:
            vzyal = 0
            if lvl == "1":
                level = 1
            elif lvl == "2":
                level = 2
            elif lvl == "3":
                level = 3

        if keys[pygame.K_s]:

            if pers[0] >= 340 and pers[0] <= 380 and pers[1] <= 340:
                pers[1] += 10

        if keys[pygame.K_w]:
            if pers[0] >= 340 and pers[0] <= 380 and pers[1] >= whi:
                pers[1] -= 10

        if keys[pygame.K_a]:
            if sel == 0:
                if pers[0] != left:
                    pers[0] -= 10
                    if vzyal == 1:
                        if level == 1:
                            box[0] -= 10
                        elif level == 2:
                            box1[0] -= 10
                        elif level == 3:
                            box2[0] -= 10
            else:
                if angle <= 150:
                    angle += 3
        if keys[pygame.K_l] and keys[pygame.K_o]:
            playsound(2)
        if keys[pygame.K_e]:
            if sel == 1:
                vilet = 0
                otskok = 0
                vilet = 1
                print(angle)

                if angle <= 152 and angle >= 140:
                    nachalo_poletel = [240, 281]
                    kak_letit = 2
                if angle <= 139 and angle >= 130:
                    nachalo_poletel = [245, 300]
                    kak_letit = 5
                if angle <= 130 and angle >= 108:
                    nachalo_poletel = [245, 315]
                    kak_letit = 7
                if angle <= 108 and angle >= 100:
                    nachalo_poletel = [255, 330]
                    kak_letit = 10

        if keys[pygame.K_d]:
            if sel == 0:
                if zvet == red:
                    if pers[0] != right:
                        pers[0] += 10
                        if vzyal == 1:
                            if level == 1:
                                box[0] += 10
                            elif level == 2:
                                box1[0] += 10
                            elif level == 3:
                                box2[0] += 10
                else:
                    pers[0] += 10
                    if vzyal == 1:
                        box[0] += 10
            else:
                if angle >= 106:
                    angle -= 3

        pygame.display.flip()

        clock.tick(50)
    pygame.quit()
